import { useState, useEffect, useRef, useCallback } from "react";
import { BotEngine, BotEvent, BotPhase, TickEntry } from "../BotEngine";
import { TickStrip } from "../components/TickStrip";
import { usePersistentStats } from "../hooks/usePersistentStats";
import { useSessionPersistence } from "../hooks/useSessionPersistence";

const MAX_TICKS = 60;

const PHASE_LABELS: Record<BotPhase, string> = {
  WAIT_START: "Scanning",
  BUYING: "Buying",
  RECOVERY: "Recovery",
};

const PHASE_COLORS: Record<BotPhase, string> = {
  WAIT_START: "text-muted-foreground",
  BUYING: "text-emerald-400",
  RECOVERY: "text-orange-400",
};


export default function BotDashboard() {
  const [token, setToken] = useState("");
  const [connected, setConnected] = useState(false);
  const [authorized, setAuthorized] = useState(false);
  const [phase, setPhase] = useState<BotPhase>("WAIT_START");
  const [ticks, setTicks] = useState<TickEntry[]>([]);
  const [statusMsg, setStatusMsg] = useState("Enter your Deriv API token to start");
  const [flashResult, setFlashResult] = useState<"win" | "loss" | null>(null);
  const [balance, setBalance] = useState<{ amount: number; currency: string } | null>(null);
  const [showClearConfirm, setShowClearConfirm] = useState(false);
  const [showClearSessionConfirm, setShowClearSessionConfirm] = useState(false);

  const engineRef = useRef<BotEngine | null>(null);
  const martingaleDepthRef = useRef(0);
  const tokenRef = useRef("");
  const manualDisconnectRef = useRef(false);
  const reconnectTimerRef = useRef<ReturnType<typeof setTimeout> | null>(null);
  const reconnectAttemptsRef = useRef(0);

  const { stats, recordWin, recordLoss, recordSessionStart, clearMemory } =
    usePersistentStats();
  const { session, addWin, addLoss, clearSession } = useSessionPersistence();

  // stake shown live; initialised from last persisted value
  const [stake, setStake] = useState(() => session.lastStake);

  const handleEvent = useCallback(
    (event: BotEvent) => {
      switch (event.type) {
        case "connected":
          setConnected(true);
          setStatusMsg("Connected — authorizing...");
          break;
        case "authorized":
          setAuthorized(true);
          reconnectAttemptsRef.current = 0;
          setStatusMsg("Authorized — receiving ticks");
          recordSessionStart();
          break;
        case "balance":
          setBalance({ amount: event.balance, currency: event.currency });
          break;
        case "disconnected":
          setConnected(false);
          setAuthorized(false);
          if (manualDisconnectRef.current) {
            setStatusMsg("Disconnected. Your stats are saved.");
          } else {
            // Unexpected disconnect — schedule reconnect with exponential backoff
            const attempt = reconnectAttemptsRef.current + 1;
            reconnectAttemptsRef.current = attempt;
            const delay = Math.min(3000 * Math.pow(2, attempt - 1), 30000);
            setStatusMsg(`Disconnected — reconnecting in ${Math.round(delay / 1000)}s (attempt ${attempt})…`);
            reconnectTimerRef.current = setTimeout(() => {
              if (!manualDisconnectRef.current && tokenRef.current) {
                setStatusMsg("Reconnecting…");
                const engine = new BotEngine();
                engine.setListener(handleEvent);
                engineRef.current = engine;
                engine.connect(tokenRef.current);
              }
            }, delay);
          }
          break;
        case "error":
          setStatusMsg("Error: " + event.message);
          break;
        case "phase":
          setPhase(event.phase);
          break;
        case "tick":
          setTicks((prev) => {
            const next = [...prev, event.entry];
            return next.length > MAX_TICKS ? next.slice(next.length - MAX_TICKS) : next;
          });
          break;
        case "buy":
          setStake(event.stake);
          setStatusMsg(`Buy sent — $${event.stake.toFixed(2)}`);
          break;
        case "win":
          setStake(0.35);
          setFlashResult("win");
          setTimeout(() => setFlashResult(null), 1000);
          addWin({ type: "win", stake: event.stake, digit: event.digit, time: new Date().toISOString() });
          setStatusMsg("Win! Stake reset to $0.35");
          recordWin();
          martingaleDepthRef.current = 0;
          break;
        case "loss": {
          martingaleDepthRef.current += 1;
          const depth = martingaleDepthRef.current;
          setStake(event.newStake);
          setFlashResult("loss");
          setTimeout(() => setFlashResult(null), 1000);
          addLoss(
            { type: "loss", stake: event.stake, digit: event.digit, newStake: event.newStake, time: new Date().toISOString() },
            event.newStake
          );
          setStatusMsg(`Loss — next stake $${event.newStake.toFixed(2)}`);
          recordLoss(event.newStake, depth);
          break;
        }
        case "reset":
          setStatusMsg("Scanning for start digit...");
          martingaleDepthRef.current = 0;
          break;
      }
    },
    [recordWin, recordLoss, recordSessionStart]
  );

  const handleConnect = () => {
    if (!token.trim()) return;
    manualDisconnectRef.current = false;
    reconnectAttemptsRef.current = 0;
    tokenRef.current = token.trim();
    if (reconnectTimerRef.current) {
      clearTimeout(reconnectTimerRef.current);
      reconnectTimerRef.current = null;
    }
    const engine = new BotEngine();
    engine.setListener(handleEvent);
    engineRef.current = engine;
    engine.connect(token.trim());
    setStatusMsg("Connecting...");
  };

  const handleDisconnect = () => {
    manualDisconnectRef.current = true;
    if (reconnectTimerRef.current) {
      clearTimeout(reconnectTimerRef.current);
      reconnectTimerRef.current = null;
    }
    engineRef.current?.disconnect();
    engineRef.current = null;
    tokenRef.current = "";
    setConnected(false);
    setAuthorized(false);
    setTicks([]);
    setPhase("WAIT_START");
    setBalance(null);
    martingaleDepthRef.current = 0;
    setStatusMsg("Disconnected. Your stats are saved.");
  };

  useEffect(() => {
    return () => {
      manualDisconnectRef.current = true;
      if (reconnectTimerRef.current) clearTimeout(reconnectTimerRef.current);
      engineRef.current?.disconnect();
    };
  }, []);

  const winRate = session.wins + session.losses > 0
    ? Math.round((session.wins / (session.wins + session.losses)) * 100)
    : 0;

  const formattedLastUpdated = stats.lastUpdated
    ? new Date(stats.lastUpdated).toLocaleString()
    : null;

  return (
    <div
      className={[
        "min-h-screen bg-background transition-colors duration-700 px-4 py-6",
        flashResult === "win"
          ? "bg-emerald-950/10"
          : flashResult === "loss"
          ? "bg-red-950/10"
          : "",
      ]
        .filter(Boolean)
        .join(" ")}
    >
      <div className="max-w-5xl mx-auto space-y-5">
        {/* Header */}
        <div className="flex items-start justify-between gap-4">
          <div>
            <h1 className="text-2xl font-bold tracking-tight text-foreground font-mono">
              Deriv Tick Bot
            </h1>
            <p className="text-sm text-muted-foreground mt-0.5">
              DIGITUNDER · R_100 · Barrier: 3 · Qualify: 6× digit &gt; 3
            </p>
          </div>
          <div className="flex items-center gap-2 text-sm mt-1">
            <span
              className={[
                "w-2.5 h-2.5 rounded-full",
                authorized
                  ? "bg-emerald-400 shadow-[0_0_6px_rgba(52,211,153,0.6)]"
                  : connected
                  ? "bg-yellow-400 animate-pulse"
                  : "bg-white/20",
              ].join(" ")}
            />
            <span className="text-muted-foreground">
              {authorized ? "Live" : connected ? "Connecting" : "Offline"}
            </span>
          </div>
        </div>

        {/* Token input */}
        {!connected && (
          <div className="bg-card border border-card-border rounded-xl p-5">
            <label className="block text-sm text-muted-foreground mb-2 font-medium">
              Deriv API Token
            </label>
            <div className="flex gap-3">
              <input
                type="password"
                value={token}
                onChange={(e) => setToken(e.target.value)}
                onKeyDown={(e) => e.key === "Enter" && handleConnect()}
                placeholder="Paste your API token..."
                className="flex-1 bg-input border border-border rounded-lg px-4 py-2.5 text-sm font-mono text-foreground placeholder:text-muted-foreground focus:outline-none focus:ring-2 focus:ring-ring"
              />
              <button
                onClick={handleConnect}
                disabled={!token.trim()}
                className="px-5 py-2.5 bg-primary text-primary-foreground rounded-lg text-sm font-semibold disabled:opacity-40 hover:opacity-90 transition-opacity"
              >
                Connect
              </button>
            </div>
            <p className="text-xs text-muted-foreground mt-2">
              Generate a token at{" "}
              <a
                href="https://app.deriv.com/account/api-token"
                target="_blank"
                rel="noopener noreferrer"
                className="text-primary hover:underline"
              >
                app.deriv.com/account/api-token
              </a>{" "}
              with "Trade" permission.
            </p>
          </div>
        )}

        {/* Status bar */}
        <div className="flex items-center justify-between bg-card border border-card-border rounded-xl px-5 py-3">
          <div className="flex items-center gap-3">
            <span className="text-xs text-muted-foreground uppercase tracking-widest font-mono">
              Phase
            </span>
            <span className={`text-sm font-bold font-mono ${PHASE_COLORS[phase]}`}>
              {PHASE_LABELS[phase]}
            </span>
          </div>
          <div className="text-xs text-muted-foreground text-center flex-1 px-4">
            {statusMsg}
          </div>
          {connected && (
            <button
              onClick={handleDisconnect}
              className="text-xs text-red-400 hover:text-red-300 font-medium transition-colors"
            >
              Disconnect
            </button>
          )}
        </div>

        {/* Live stats row */}
        <div className="grid grid-cols-5 gap-3">
          <StatCard
            label="Balance"
            value={balance ? `${balance.amount.toFixed(2)} ${balance.currency}` : "—"}
            color={balance ? "text-foreground" : "text-muted-foreground"}
          />
          <StatCard label="Stake" value={`$${stake.toFixed(2)}`} color="text-foreground" />
          <StatCard label="Wins" value={String(session.wins)} color="text-emerald-400" />
          <StatCard label="Losses" value={String(session.losses)} color="text-red-400" />
          <StatCard label="Win Rate" value={`${winRate}%`} color="text-sky-400" />
        </div>

        {/* Persistent memory panel */}
        <div className="bg-card border border-card-border rounded-xl p-4">
          <div className="flex items-center justify-between mb-3">
            <div className="flex items-center gap-2">
              <span className="text-sm font-semibold text-muted-foreground uppercase tracking-widest font-mono">
                Memory
              </span>
              <span className="text-[10px] bg-primary/20 text-primary px-2 py-0.5 rounded-full font-mono uppercase tracking-wider">
                Persisted
              </span>
            </div>
            <div className="flex items-center gap-3">
              {formattedLastUpdated && (
                <span className="text-xs text-muted-foreground/50 font-mono">
                  Last updated: {formattedLastUpdated}
                </span>
              )}
              {!showClearConfirm ? (
                <button
                  onClick={() => setShowClearConfirm(true)}
                  className="text-xs text-muted-foreground hover:text-red-400 transition-colors font-mono"
                >
                  Clear
                </button>
              ) : (
                <div className="flex items-center gap-2">
                  <span className="text-xs text-muted-foreground">Are you sure?</span>
                  <button
                    onClick={() => { clearMemory(); setShowClearConfirm(false); }}
                    className="text-xs text-red-400 hover:text-red-300 font-semibold transition-colors"
                  >
                    Yes, clear
                  </button>
                  <button
                    onClick={() => setShowClearConfirm(false)}
                    className="text-xs text-muted-foreground hover:text-foreground transition-colors"
                  >
                    Cancel
                  </button>
                </div>
              )}
            </div>
          </div>

          <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
            <MemoryCard
              label="Highest Stake Ever"
              value={stats.maxStake > 0 ? `$${stats.maxStake.toFixed(2)}` : "—"}
              subtext="Peak martingale amount"
              color="text-orange-400"
              highlight={stats.maxStake > 0}
            />
            <MemoryCard
              label="Deepest Chain"
              value={stats.maxMartingaleDepth > 0 ? `${stats.maxMartingaleDepth} loss${stats.maxMartingaleDepth === 1 ? "" : "es"}` : "—"}
              subtext={
                stats.maxMartingaleDepth > 0
                  ? `Happened ${stats.deepestChainCount}× across all sessions`
                  : "Max consecutive losses"
              }
              color="text-red-400"
              highlight={stats.maxMartingaleDepth > 0}
            />
            <MemoryCard
              label="Total Wins"
              value={stats.totalWins > 0 ? String(stats.totalWins) : "—"}
              subtext="Across all sessions"
              color="text-emerald-400"
            />
            <MemoryCard
              label="Sessions Run"
              value={stats.sessionsRun > 0 ? String(stats.sessionsRun) : "—"}
              subtext="Times connected"
              color="text-sky-400"
            />
          </div>

          {stats.maxMartingaleDepth >= 3 && (
            <div className="mt-3 px-3 py-2 rounded-lg bg-orange-950/30 border border-orange-500/20 text-xs text-orange-300 font-mono">
              ⚠ Your bot has hit a {stats.maxMartingaleDepth}-loss chain before.
              {" "}At 1.5× Martingale that's a stake of $
              {(0.35 * Math.pow(1.5, stats.maxMartingaleDepth)).toFixed(2)}.
              {" "}Make sure your balance can absorb this.
            </div>
          )}
        </div>

        {/* Tick strip */}
        <div className="bg-card border border-card-border rounded-xl p-4">
          <div className="flex items-center justify-between mb-3">
            <h2 className="text-sm font-semibold text-muted-foreground uppercase tracking-widest font-mono">
              Tick Stream
            </h2>
            <div className="flex items-center gap-4 text-xs text-muted-foreground/70">
              <LegendItem color="text-yellow-400" label="start" />
              <LegendItem color="text-sky-400" label="✓ qualify" />
              <LegendItem color="text-emerald-400" label="buy" />
            </div>
          </div>
          <TickStrip ticks={ticks} />
        </div>

        {/* Trade log */}
        <div className="bg-card border border-card-border rounded-xl p-4">
          <div className="flex items-center justify-between mb-3">
            <h2 className="text-sm font-semibold text-muted-foreground uppercase tracking-widest font-mono">
              Trade Log
            </h2>
            {session.trades.length > 0 && (
              !showClearSessionConfirm ? (
                <button
                  onClick={() => setShowClearSessionConfirm(true)}
                  className="text-xs text-muted-foreground hover:text-red-400 transition-colors font-mono"
                >
                  Clear session
                </button>
              ) : (
                <div className="flex items-center gap-2">
                  <span className="text-xs text-muted-foreground">Clear all session data?</span>
                  <button
                    onClick={() => { clearSession(); setStake(0.35); setShowClearSessionConfirm(false); }}
                    className="text-xs text-red-400 hover:text-red-300 font-semibold"
                  >
                    Yes
                  </button>
                  <button
                    onClick={() => setShowClearSessionConfirm(false)}
                    className="text-xs text-muted-foreground hover:text-foreground"
                  >
                    Cancel
                  </button>
                </div>
              )
            )}
          </div>
          {session.trades.length === 0 ? (
            <p className="text-xs text-muted-foreground/50 font-mono py-2">
              No trades yet — they will appear here and stay after disconnect.
            </p>
          ) : (
            <div className="space-y-1.5 max-h-52 overflow-y-auto">
              {session.trades.map((t) => (
                <div
                  key={t.id}
                  className="flex items-center gap-3 text-sm py-2 px-3 rounded-lg bg-white/5"
                >
                  <span
                    className={`w-10 text-center text-xs font-bold font-mono ${
                      t.type === "win" ? "text-emerald-400" : "text-red-400"
                    }`}
                  >
                    {t.type === "win" ? "WIN" : "LOSS"}
                  </span>
                  <span className="text-muted-foreground text-xs font-mono">
                    ${t.stake.toFixed(2)}
                  </span>
                  <span className="text-muted-foreground text-xs">digit {t.digit}</span>
                  {t.newStake && (
                    <span className="text-orange-400 text-xs font-mono">
                      → ${t.newStake.toFixed(2)}
                    </span>
                  )}
                  <span className="ml-auto text-muted-foreground/50 text-xs font-mono">
                    {new Date(t.time).toLocaleTimeString()}
                  </span>
                </div>
              ))}
            </div>
          )}
        </div>

        {/* Pattern guide */}
        <div className="bg-card border border-card-border rounded-xl p-4">
          <h2 className="text-sm font-semibold text-muted-foreground uppercase tracking-widest font-mono mb-3">
            Pattern Guide
          </h2>
          <PatternGuide />
        </div>
      </div>
    </div>
  );
}

function StatCard({ label, value, color }: { label: string; value: string; color: string }) {
  return (
    <div className="bg-card border border-card-border rounded-xl p-4">
      <div className="text-xs text-muted-foreground uppercase tracking-widest font-mono mb-1">
        {label}
      </div>
      <div className={`text-xl font-bold font-mono ${color}`}>{value}</div>
    </div>
  );
}

function MemoryCard({
  label,
  value,
  subtext,
  color,
  highlight,
}: {
  label: string;
  value: string;
  subtext: string;
  color: string;
  highlight?: boolean;
}) {
  return (
    <div
      className={[
        "rounded-lg p-3 border",
        highlight
          ? "bg-white/5 border-white/10"
          : "bg-white/[0.02] border-white/5",
      ].join(" ")}
    >
      <div className="text-[10px] text-muted-foreground uppercase tracking-widest font-mono mb-1">
        {label}
      </div>
      <div className={`text-lg font-bold font-mono ${value === "—" ? "text-muted-foreground/40" : color}`}>
        {value}
      </div>
      <div className="text-[10px] text-muted-foreground/50 font-mono mt-0.5">{subtext}</div>
    </div>
  );
}

function LegendItem({ color, label }: { color: string; label: string }) {
  return <span className={`${color} font-mono`}>{label}</span>;
}

function PatternGuide() {
  return (
    <div className="flex flex-wrap gap-2 items-end">
      {/* 6 consecutive qualifying digits */}
      <PatternCell digit={7} label="start" labelColor="text-yellow-400" borderColor="border-yellow-400/60" bgColor="bg-yellow-950/40" note="1st >3" />
      <PatternCell digit={6} label="check" labelColor="text-sky-400" borderColor="border-sky-400/60" bgColor="bg-sky-950/40" note="2nd" />
      <PatternCell digit={9} label="check" labelColor="text-violet-400" borderColor="border-violet-400/60" bgColor="bg-violet-950/40" note="3rd" />
      <PatternCell digit={5} label="check" labelColor="text-pink-400" borderColor="border-pink-400/60" bgColor="bg-pink-950/40" note="4th" />
      <PatternCell digit={8} label="check" labelColor="text-rose-300" borderColor="border-rose-300/60" bgColor="bg-rose-950/40" note="5th" />
      <PatternCell digit={4} label="check" labelColor="text-orange-300" borderColor="border-orange-300/60" bgColor="bg-orange-950/40" note="6th" />
      <Separator />
      {/* Buy every tick until win */}
      <PatternCell digit={1} label="buy" labelColor="text-emerald-400" borderColor="border-emerald-400/60" bgColor="bg-emerald-950/40" note="buy" />
      <PatternCell digit={0} label="buy" labelColor="text-emerald-400" borderColor="border-emerald-400/60" bgColor="bg-emerald-950/40" note="buy" />
      <PatternCell digit={2} label="buy" labelColor="text-emerald-400" borderColor="border-emerald-400/60" bgColor="bg-emerald-950/40" note="WIN ✓" />
    </div>
  );
}

function Separator() {
  return (
    <div className="flex flex-col items-center justify-center h-10 px-1">
      <div className="w-px h-6 bg-white/10" />
    </div>
  );
}

function PatternCell({
  digit, label, labelColor, borderColor, bgColor, note, isDot,
}: {
  digit: number; label: string | null; labelColor?: string;
  borderColor?: string; bgColor?: string; note?: string; isDot?: boolean;
}) {
  return (
    <div className="flex flex-col items-center gap-0.5">
      <div className="h-5 flex items-center justify-center">
        {label === null ? (
          <div className="h-5" />
        ) : isDot ? (
          <span className="w-1.5 h-1.5 rounded-full bg-white/30 inline-block" />
        ) : (
          <span className={`text-[9px] font-bold tracking-widest uppercase ${labelColor}`}>
            {label === "check" ? "✓" : label}
          </span>
        )}
      </div>
      <div
        className={[
          "w-9 h-9 rounded-lg border flex items-center justify-center font-mono font-bold text-base",
          bgColor ?? "bg-white/5",
          borderColor ?? "border-white/10",
          digit > 3 ? "text-emerald-400" : "text-red-400",
        ].join(" ")}
      >
        {digit}
      </div>
      {note && (
        <span className="text-[9px] text-muted-foreground/60 text-center font-mono max-w-[40px] leading-tight mt-0.5">
          {note}
        </span>
      )}
    </div>
  );
}
