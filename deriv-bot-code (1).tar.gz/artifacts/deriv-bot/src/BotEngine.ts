const DERIV_WS = 'wss://ws.derivws.com/websockets/v3?app_id=1089';

const BASE_STAKE = 0.35;
const MARTINGALE = 1.5;
const SYMBOL = 'R_100';
const QUALIFY_STREAK = 6; // consecutive digits > 3 needed before buying starts

export type TickLabel =
  | 'start'
  | 'check'
  | 'buy'
  | null;

export interface TickEntry {
  epoch: number;
  digit: number;
  quote: string;
  label: TickLabel;
  phase: BotPhase;
  isWin?: boolean;
  isLoss?: boolean;
}

export type BotPhase =
  | 'WAIT_START'
  | 'BUYING'
  | 'RECOVERY';

export type BotEvent =
  | { type: 'tick'; entry: TickEntry }
  | { type: 'phase'; phase: BotPhase }
  | { type: 'buy'; stake: number }
  | { type: 'win'; stake: number; digit: number }
  | { type: 'loss'; stake: number; newStake: number; digit: number }
  | { type: 'connected' }
  | { type: 'authorized' }
  | { type: 'balance'; balance: number; currency: string }
  | { type: 'disconnected' }
  | { type: 'error'; message: string }
  | { type: 'reset' };

export class BotEngine {
  private ws: WebSocket | null = null;

  private proposalId: string | null = null;
  private proposalReady = false;
  private buyPending = false;

  private lastEpoch: number | null = null;

  private phase: BotPhase = 'WAIT_START';

  private consecutiveCount = 0; // qualifying streak counter

  private currentStake = BASE_STAKE;

  private settlementExpected = false;
  private settlementEpoch: number | null = null;

  private listener: ((event: BotEvent) => void) | null = null;

  setListener(fn: (event: BotEvent) => void) {
    this.listener = fn;
  }

  private emit(event: BotEvent) {
    this.listener?.(event);
  }

  connect(token: string) {
    this.ws = new WebSocket(DERIV_WS);

    this.ws.onopen = () => {
      this.emit({ type: 'connected' });
      this.ws!.send(JSON.stringify({ authorize: token }));
    };

    this.ws.onmessage = (msg) => {
      const data = JSON.parse(msg.data);

      if (data.error) {
        this.emit({ type: 'error', message: data.error.message });
        return;
      }

      if (data.msg_type === 'authorize') {
        this.emit({ type: 'authorized' });
        this.ws!.send(JSON.stringify({ ticks: SYMBOL, subscribe: 1 }));
        this.ws!.send(JSON.stringify({ balance: 1, subscribe: 1 }));
      }

      if (data.msg_type === 'balance') {
        this.emit({
          type: 'balance',
          balance: data.balance.balance,
          currency: data.balance.currency,
        });
      }

      if (data.msg_type === 'proposal') {
        this.proposalId = data.proposal.id;
        this.proposalReady = true;
        // A tick arrived before the proposal was ready — buy now
        if (this.buyPending) {
          this.buyPending = false;
          this.executeBuy();
        }
      }

      if (data.msg_type === 'buy') {
        this.emit({ type: 'buy', stake: this.currentStake });
      }

      if (data.msg_type === 'tick') {
        this.processTick(data.tick);
      }
    };

    this.ws.onclose = () => {
      this.emit({ type: 'disconnected' });
    };

    this.ws.onerror = () => {
      this.emit({ type: 'error', message: 'WebSocket error' });
    };
  }

  disconnect() {
    if (this.ws) {
      this.ws.close();
      this.ws = null;
    }
  }

  private extractDigit(quote: string): number {
    return parseInt(Number(quote).toFixed(2).slice(-1));
  }

  private processTick(tick: { epoch: number; quote: string }) {
    if (!tick) return;
    if (this.lastEpoch !== null && tick.epoch <= this.lastEpoch) return;

    this.lastEpoch = tick.epoch;
    const digit = this.extractDigit(tick.quote);

    const isSettlement =
      this.settlementExpected &&
      this.settlementEpoch !== null &&
      tick.epoch >= this.settlementEpoch;

    const label = this.computeLabel(digit, isSettlement);

    const entry: TickEntry = {
      epoch: tick.epoch,
      digit,
      quote: tick.quote,
      label,
      phase: this.phase,
    };

    this.emit({ type: 'tick', entry });

    // Settlement tick: resolve trade
    if (isSettlement) {
      this.resolveTrade(digit, entry);
      // If we're still in BUYING or RECOVERY (loss), buy on this same tick
      // so no tick is ever wasted
      if (this.phase === 'BUYING' || this.phase === 'RECOVERY') {
        this.buyTick();
      }
      return;
    }

    // Route to phase handler
    if (this.phase === 'WAIT_START') {
      this.scanTick(digit);
    } else {
      // BUYING or RECOVERY: buy on every tick
      this.buyTick();
    }
  }

  private computeLabel(digit: number, isSettlement: boolean): TickLabel {
    // Settlement ticks show win/loss via entry.isWin/isLoss — no extra label
    if (isSettlement) return null;

    if (this.phase === 'WAIT_START') {
      if (digit > 3) {
        if (this.consecutiveCount === 0) return 'start';
        return 'check';
      }
      return null;
    }

    // BUYING / RECOVERY — every tick is a buy tick
    return 'buy';
  }

  // Scanning: count consecutive digits > 3; at QUALIFY_STREAK, start buying
  private scanTick(digit: number) {
    if (digit > 3) {
      this.consecutiveCount++;
      if (this.consecutiveCount >= QUALIFY_STREAK) {
        this.consecutiveCount = 0;
        this.phase = 'BUYING';
        this.emit({ type: 'phase', phase: 'BUYING' });
        // Request proposal and register buy intent on this same tick
        this.prepareProposal();
        this.buyTick();
      }
    } else {
      this.consecutiveCount = 0;
    }
  }

  // Buying: fire a trade on every tick; pre-fetch the next proposal right after
  private buyTick() {
    if (this.proposalReady) {
      this.executeBuy();
      // Immediately request the next proposal so it's ready for the following tick
      this.prepareProposal();
    } else {
      // Proposal hasn't arrived yet; buy as soon as it does
      this.buyPending = true;
    }
  }

  private prepareProposal() {
    if (!this.ws) return;
    this.proposalReady = false;
    this.proposalId = null;
    this.ws.send(JSON.stringify({
      proposal: 1,
      amount: Number(this.currentStake.toFixed(2)),
      basis: 'stake',
      contract_type: 'DIGITUNDER',
      currency: 'USD',
      duration: 1,
      duration_unit: 't',
      symbol: SYMBOL,
      barrier: '3',
    }));
  }

  private executeBuy() {
    if (!this.ws || !this.proposalId) return;
    this.ws.send(JSON.stringify({
      buy: this.proposalId,
      price: Number(this.currentStake.toFixed(2)),
    }));
    this.proposalId = null;
    this.proposalReady = false;
    this.settlementExpected = true;
    this.settlementEpoch = (this.lastEpoch || 0) + 1;
  }

  private resolveTrade(settlementDigit: number, entry: TickEntry) {
    this.settlementExpected = false;
    const win = settlementDigit < 3;

    if (win) {
      entry.isWin = true;
      this.emit({ type: 'win', stake: this.currentStake, digit: settlementDigit });
      this.currentStake = BASE_STAKE;
      this.resetBot();
    } else {
      entry.isLoss = true;
      const newStake = Number((this.currentStake * MARTINGALE).toFixed(2));
      this.emit({ type: 'loss', stake: this.currentStake, newStake, digit: settlementDigit });
      this.currentStake = newStake;
      // Stay in buying mode — switch to RECOVERY phase and immediately pre-fetch
      this.phase = 'RECOVERY';
      this.emit({ type: 'phase', phase: 'RECOVERY' });
      this.prepareProposal(); // ready for the very next tick
    }
  }

  private resetBot() {
    this.phase = 'WAIT_START';
    this.consecutiveCount = 0;
    this.proposalId = null;
    this.proposalReady = false;
    this.buyPending = false;
    this.settlementExpected = false;
    this.settlementEpoch = null;
    this.emit({ type: 'phase', phase: 'WAIT_START' });
    this.emit({ type: 'reset' });
  }

  get stake() {
    return this.currentStake;
  }

  get currentPhase() {
    return this.phase;
  }
}
