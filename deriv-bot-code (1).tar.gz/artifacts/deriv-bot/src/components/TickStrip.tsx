import { useEffect, useRef } from "react";
import type { TickEntry } from "../BotEngine";

interface TickStripProps {
  ticks: TickEntry[];
}

function getDigitColor(digit: number) {
  if (digit > 3) return "text-emerald-400";
  return "text-red-400";
}

function getBorderColor(entry: TickEntry) {
  if (entry.label === "buy") return "border-emerald-400 shadow-[0_0_10px_rgba(52,211,153,0.4)]";
  if (entry.label === "start") return "border-yellow-400 shadow-[0_0_8px_rgba(250,204,21,0.3)]";
  if (entry.label === "check") return "border-sky-400 shadow-[0_0_8px_rgba(56,189,248,0.3)]";
  if (entry.isWin) return "border-emerald-400";
  if (entry.isLoss) return "border-red-400";
  return "border-white/10";
}

function getBgColor(entry: TickEntry) {
  if (entry.label === "buy") return "bg-emerald-950/60";
  if (entry.label === "start") return "bg-yellow-950/60";
  if (entry.label === "check") return "bg-sky-950/60";
  if (entry.isWin) return "bg-emerald-950/40";
  if (entry.isLoss) return "bg-red-950/40";
  return "bg-white/5";
}

function LabelBadge({ label }: { label: TickEntry["label"] }) {
  if (!label) return <div className="h-5" />;

  if (label === "start") {
    return (
      <div className="h-5 flex items-center justify-center">
        <span className="text-[9px] font-bold tracking-widest uppercase text-yellow-400 label-pop">
          start
        </span>
      </div>
    );
  }

  if (label === "check") {
    return (
      <div className="h-5 flex items-center justify-center">
        <span className="text-[13px] font-bold text-sky-400 label-pop leading-none">✓</span>
      </div>
    );
  }

  if (label === "buy") {
    return (
      <div className="h-5 flex items-center justify-center">
        <span className="text-[9px] font-bold tracking-widest uppercase text-emerald-400 label-pop">
          buy
        </span>
      </div>
    );
  }

  return <div className="h-5" />;
}

export function TickStrip({ ticks }: TickStripProps) {
  const endRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    endRef.current?.scrollIntoView({ behavior: "smooth", block: "nearest", inline: "end" });
  }, [ticks.length]);

  if (ticks.length === 0) {
    return (
      <div className="flex items-center justify-center h-24 text-muted-foreground text-sm">
        Waiting for ticks...
      </div>
    );
  }

  return (
    <div className="overflow-x-auto pb-2">
      <div className="flex gap-2 min-w-max px-1">
        {ticks.map((entry, i) => (
          <div
            key={entry.epoch}
            className="flex flex-col items-center gap-0.5 tick-enter"
            style={{ animationDelay: i === ticks.length - 1 ? "0ms" : "0ms" }}
          >
            <LabelBadge label={entry.label} />

            <div
              className={[
                "w-10 h-10 rounded-lg border flex items-center justify-center transition-all font-mono font-bold text-lg",
                getBgColor(entry),
                getBorderColor(entry),
                entry.label === "buy" ? "buy-pulse" : "",
              ]
                .filter(Boolean)
                .join(" ")}
            >
              <span className={getDigitColor(entry.digit)}>{entry.digit}</span>
            </div>

            <div className="text-[9px] text-muted-foreground/50 font-mono">
              {entry.epoch % 1000}
            </div>
          </div>
        ))}
        <div ref={endRef} />
      </div>
    </div>
  );
}
