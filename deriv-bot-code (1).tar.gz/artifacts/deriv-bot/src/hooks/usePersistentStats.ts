import { useState, useCallback } from "react";

const STORAGE_KEY = "derivBot_stats_v1";

export interface PersistentStats {
  maxStake: number;
  maxMartingaleDepth: number;
  deepestChainCount: number;
  totalWins: number;
  totalLosses: number;
  sessionsRun: number;
  lastUpdated: string | null;
}

function defaultStats(): PersistentStats {
  return {
    maxStake: 0,
    maxMartingaleDepth: 0,
    deepestChainCount: 0,
    totalWins: 0,
    totalLosses: 0,
    sessionsRun: 0,
    lastUpdated: null,
  };
}

function load(): PersistentStats {
  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    if (!raw) return defaultStats();
    return { ...defaultStats(), ...JSON.parse(raw) };
  } catch {
    return defaultStats();
  }
}

function save(stats: PersistentStats) {
  try {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(stats));
  } catch {
    // storage full or unavailable
  }
}

export function usePersistentStats() {
  const [stats, setStats] = useState<PersistentStats>(load);

  const update = useCallback((updater: (prev: PersistentStats) => PersistentStats) => {
    setStats((prev) => {
      const next = updater(prev);
      next.lastUpdated = new Date().toISOString();
      save(next);
      return next;
    });
  }, []);

  const recordWin = useCallback(() => {
    update((prev) => ({
      ...prev,
      totalWins: prev.totalWins + 1,
    }));
  }, [update]);

  const recordLoss = useCallback((newStake: number, currentDepth: number) => {
    update((prev) => {
      const newMax = Math.max(prev.maxMartingaleDepth, currentDepth);
      let newCount = prev.deepestChainCount;
      if (currentDepth > prev.maxMartingaleDepth) {
        newCount = 1;
      } else if (currentDepth === prev.maxMartingaleDepth && currentDepth > 0) {
        newCount = prev.deepestChainCount + 1;
      }
      return {
        ...prev,
        totalLosses: prev.totalLosses + 1,
        maxStake: Math.max(prev.maxStake, newStake),
        maxMartingaleDepth: newMax,
        deepestChainCount: newCount,
      };
    });
  }, [update]);

  const recordSessionStart = useCallback(() => {
    update((prev) => ({
      ...prev,
      sessionsRun: prev.sessionsRun + 1,
    }));
  }, [update]);

  const clearMemory = useCallback(() => {
    const fresh = defaultStats();
    save(fresh);
    setStats(fresh);
  }, []);

  return { stats, recordWin, recordLoss, recordSessionStart, clearMemory };
}
