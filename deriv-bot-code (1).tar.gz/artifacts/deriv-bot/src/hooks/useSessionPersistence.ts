import { useState, useCallback } from "react";

const SESSION_KEY = "derivBot_session_v1";

export interface PersistedTrade {
  id: number;
  type: "win" | "loss";
  stake: number;
  digit: number;
  newStake?: number;
  time: string;
}

export interface SessionData {
  wins: number;
  losses: number;
  lastStake: number;
  trades: PersistedTrade[];
}

function defaultSession(): SessionData {
  return { wins: 0, losses: 0, lastStake: 0.35, trades: [] };
}

function load(): SessionData {
  try {
    const raw = localStorage.getItem(SESSION_KEY);
    if (!raw) return defaultSession();
    return { ...defaultSession(), ...JSON.parse(raw) };
  } catch {
    return defaultSession();
  }
}

function save(data: SessionData) {
  try {
    localStorage.setItem(SESSION_KEY, JSON.stringify(data));
  } catch {}
}

export function useSessionPersistence() {
  const [session, setSession] = useState<SessionData>(load);

  const update = useCallback((updater: (prev: SessionData) => SessionData) => {
    setSession((prev) => {
      const next = updater(prev);
      save(next);
      return next;
    });
  }, []);

  const addWin = useCallback(
    (trade: Omit<PersistedTrade, "id">) => {
      update((prev) => ({
        ...prev,
        wins: prev.wins + 1,
        lastStake: 0.35,
        trades: [
          { ...trade, id: Date.now() },
          ...prev.trades.slice(0, 49),
        ],
      }));
    },
    [update]
  );

  const addLoss = useCallback(
    (trade: Omit<PersistedTrade, "id">, newStake: number) => {
      update((prev) => ({
        ...prev,
        losses: prev.losses + 1,
        lastStake: newStake,
        trades: [
          { ...trade, id: Date.now() },
          ...prev.trades.slice(0, 49),
        ],
      }));
    },
    [update]
  );

  const clearSession = useCallback(() => {
    const fresh = defaultSession();
    save(fresh);
    setSession(fresh);
  }, []);

  return { session, addWin, addLoss, clearSession };
}
